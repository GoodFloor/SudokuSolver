#ifndef POSSIBILITY_H
#define POSSIBILITY_H

struct Possibility
{
    int i;
    int j;
    int p;
};

#endif
